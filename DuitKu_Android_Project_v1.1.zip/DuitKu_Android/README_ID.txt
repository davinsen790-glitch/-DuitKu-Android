DUITKU - PROYEK ANDROID

Isi:
- Aplikasi Android berbasis WebView.
- HTML DuitKu disimpan di app/src/main/assets/index.html.
- Penyimpanan transaksi menggunakan localStorage pada WebView.

CARA MEMBUAT APK:
1. Ekstrak folder DuitKu_Android.zip.
2. Buka Android Studio.
3. Pilih Open, lalu pilih folder DuitKu_Android.
4. Tunggu Gradle Sync selesai. Android Studio mungkin perlu mengunduh
   Android Gradle Plugin, Kotlin plugin, dan Android SDK Platform 35.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik Locate pada notifikasi hasil build.
   APK biasanya berada di app/build/outputs/apk/debug/app-debug.apk.

Catatan:
- Ini adalah proyek sumber Android, belum berupa APK yang sudah dikompilasi.
- Proyek menggunakan Android Gradle Plugin 8.7.3, Kotlin 2.0.21,
  compileSdk 35, dan minimum Android 6.0 (API 23).
- Data tersimpan lokal di aplikasi/perangkat dan tidak tersinkron ke cloud.

PEMBARUAN FITUR v1.1:
- Ubah transaksi (nama, jumlah, kategori).
- Hapus transaksi dengan konfirmasi.
- Reset jumlah tabungan dengan konfirmasi; riwayat transaksi dan target tetap tersimpan.
